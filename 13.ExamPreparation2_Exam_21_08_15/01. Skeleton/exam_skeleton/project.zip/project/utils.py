def is_positive(value):
    return value > 0